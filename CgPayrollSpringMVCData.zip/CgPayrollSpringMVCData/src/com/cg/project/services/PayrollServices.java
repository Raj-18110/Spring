package com.cg.project.services;
import java.util.ArrayList;
import com.cg.project.beans.*;
public interface PayrollServices {
	int acceptAssociateDetails(int yearlyInvestmentUnder80c,
			String firstName, String lastName, String department,
			String designation, String pancard, String emailId,int accountNumber, String bankName,
			String ifscCode,int basicsalary, int epf,
			int companyPf);
	int calculateNetSalary(int associateId);
	Associate getAssociateDetails(int associateId);
	ArrayList<Associate>getAllAsociateDetails();
}