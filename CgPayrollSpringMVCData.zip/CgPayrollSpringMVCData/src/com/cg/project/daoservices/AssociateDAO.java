package com.cg.project.daoservices;
import java.util.ArrayList;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.project.beans.Associate;
public interface AssociateDAO extends JpaRepository<Associate, Integer>{
	/*Associate save(Associate associate);
	Associate findOne(int associateId);
	ArrayList<Associate> findAll();
	boolean update(Associate associate);*/
	ArrayList<Associate> findAll();
}